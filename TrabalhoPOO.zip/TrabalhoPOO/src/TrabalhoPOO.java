/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package src;

/**
 *
 * @author Felipe
 */
public class TrabalhoPOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       AlunoDAO dao = new AlunoDAO();
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        // Criar
        Aluno a1 = new Aluno(0, "123.456.789-00", "Maria Souza",
                LocalDate.parse("15/05/2000", dateFormatter),
                "(34) 91234-5678", "maria@email.com");
        dao.criar(a1);

        // Listar
        System.out.println("=== Todos os Alunos ===");
        dao.listarTodos().forEach(a ->
                System.out.println(a.getId() + " - " + a.getNome() +
                        " | Criado em: " + a.getDataCriacao()));

        // Buscar
        Aluno encontrado = dao.buscarPorId(1);
        if (encontrado != null) {
            System.out.println("\n=== Aluno Encontrado ===");
            System.out.println("Nome: " + encontrado.getNome());
            System.out.println("Última modificação: " + encontrado.getDataModificacao());

            // Atualizar
            encontrado.setTelefone("(34) 98765-4321");
            dao.atualizar(encontrado);
            System.out.println("\nTelefone atualizado!");
        }

        // Deletar
        dao.deletar(1);
        System.out.println("\nAluno removido: " + (dao.buscarPorId(1) == null));
    }
}
    }
    
}
